
1.hdfs_hdfs_smail.json  跨租户的hdfs的小文件互导   文件大小771 KB  5千条数据量

  wf内容：通过脚本任务 执行distcp 命令 拷贝文件 到目标集群 实现跨租户的hdfs的小文件互导
  
2.hdfs_hdfs_big.json 跨租户的hdfs的大文件文件互导  文件大小2G   1千w数据量

  wf内容：通过脚本任务 执行distcp 命令 拷贝文件 到目标集群 实现跨租户的hdfs的大文件互导
  
3.hdfs_hdfs_table_only.json  跨租户表文件互导  表数据5000条
  
  wf内容：通过sql任务，在源端创建orc表，导入数据，并导出数据至hdfs目录，再通过脚本任务，执行distcp命令
          拷贝文件到目标端hdfs，然后用sql任务，在目标端创建orc表，并把拷贝的数据导入到orc表
		  
4.hdfs_hdfs_table_many.json  跨租户多表文件互导  3张orc表，数据为5000

  wf内容: 通过sql任务，在源端创建多张orc表，导入数据，并导出数据至hdfs目录，再通过脚本任务，执行distcp命令
          拷贝文件夹到目标端hdfs，然后用sql任务，在目标端创建多张orc表，并把拷贝的数据导入到orc表
          